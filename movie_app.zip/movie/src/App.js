import axios from "axios";
import { useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";


function App() {
  let [moviedata,setmoviedata]=useState([])
    // let [search,setsearch]=useState('')
    let images=`https://image.tmdb.org/t/p/w1280`;
    let inputVale=(e)=>{
        let inputName=e.target.value;
       // console.log(inputName);

        let apiUrrl;
        if(inputName != ''){
             apiUrrl=`https://api.themoviedb.org/3/search/movie?&api_key=04c35731a5ee918f014970082a0088b1&query=${inputName}`;
        }else{
             apiUrrl=`https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=04c35731a5ee918f014970082a0088b1&page=6`
        }
        
            axios.get(apiUrrl)
            .then(function (response) {
            console.log(response);
            })

            showData(apiUrrl);
    }
    
    

    let showData=(DataApi=`https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=04c35731a5ee918f014970082a0088b1&page=1`)=>{
        
        axios.get(DataApi)
        .then(function (response) {
            setmoviedata(response.data.results);
            // console.log(response.data.results);
            
    })
    }
    
    useEffect(()=>{
        showData()
        
    },[])
  return (
    <div className="App">
      <div className="movie">
            <Row className="mx-2">
                <h3>Search Movie</h3>
                <input type="text" placeholder="Search Movie"  name="name" onChange={inputVale} />
            </Row>

            <div className="row row-cols-lg-4 p-2">
                {moviedata.map((v,i)=>{
                    return(
                        <div className="movie-box">
                            <img src={images+v.poster_path} className="card-img-top"/>
                            <h5>{v.title}</h5>
                            <h6>{v.release_date}</h6>
                        </div>
                    )
                })}
            </div>
        </div>
    </div>
  );
}

export default App;
